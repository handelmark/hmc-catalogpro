// Local preview server using only built-in Node.js modules. Not intended as a production backend.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const PORT = Number(process.env.PORT)||8080;
const ROOT = __dirname;
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.csv':'text/csv; charset=utf-8','.svg':'image/svg+xml','.json':'application/json; charset=utf-8'};
http.createServer((req,res)=>{
  let requested;
  try{requested=decodeURIComponent(new URL(req.url,`http://localhost:${PORT}`).pathname)}catch{res.writeHead(400).end('Dirección incorrecta');return}
  const file=path.resolve(ROOT,'.'+(requested==='/'?'/index.html':requested));
  if(!file.startsWith(ROOT+path.sep)){res.writeHead(403).end('Acceso denegado');return}
  fs.stat(file,(error,st)=>{
    if(error||!st.isFile()){res.writeHead(404).end('Archivo no encontrado');return}
    res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','X-Content-Type-Options':'nosniff'});
    fs.createReadStream(file).pipe(res)
  })
}).listen(PORT,()=>console.log(`HMC CatalogPro está disponible: http://localhost:${PORT}`));
