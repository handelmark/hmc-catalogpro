import {STORE, EVENTS, storageGet, initialWorkspace,esc} from './common.js';
const $=id=>document.getElementById(id);
const descriptions={landing_view:'Página de venta visitada',app_open:'Editor de catálogos abierto',catalog_created:'Catálogo creado',catalog_deleted:'Catálogo eliminado',catalog_duplicated:'Catálogo duplicado',product_added:'Producto añadido',product_updated:'Producto actualizado',product_deleted:'Producto eliminado',csv_imported:'Hoja de cálculo importada',pdf_exported:'Ventana de impresión PDF abierta',html_exported:'Catálogo HTML descargado',csv_exported:'CSV exportado',backup_exported:'Copia de seguridad descargada',backup_restored:'Espacio de trabajo restaurado',theme_changed:'Estilo del catálogo cambiado',brand_updated:'Configuración de marca actualizada'};
async function render(){
  const workspace=(await storageGet(STORE))||initialWorkspace();const events=(await storageGet(EVENTS))||[];
  $('dashCatalogs').textContent=workspace.catalogs.length;$('dashEvents').textContent=events.length;
  $('dashCatCell').textContent=workspace.catalogs.length;$('dashProducts').textContent=workspace.catalogs.reduce((s,c)=>s+c.products.length,0);
  const chart=$('activityChart');chart.replaceChildren();const today=new Date();
  const days=Array.from({length:7},(_,i)=>{const d=new Date(today);d.setDate(today.getDate()-6+i);return d});
  const counts=days.map(d=>events.filter(e=>new Date(e.time).toDateString()===d.toDateString()).length);const max=Math.max(1,...counts);
  days.forEach((d,i)=>{const col=document.createElement('div');col.className='bar-col';col.title=`${counts[i]} interacciones`;col.innerHTML=`<div class="bar-fill" style="height:${Math.max(2,Math.round(counts[i]/max*135))}px"></div><span>${d.toLocaleDateString('es-ES',{weekday:'short'})}</span>`;chart.append(col)});
  $('eventsList').innerHTML=events.slice(0,6).map(e=>`<li><span>${esc(descriptions[e.type]||e.type)}<br><span class="muted tiny">${esc(String(e.details||'').slice(0,65))}</span></span><time>${new Date(e.time).toLocaleString('es-ES',{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})}</time></li>`).join('')||'<li class="muted">Todavía no hay actividad registrada en este navegador. Prueba la aplicación.</li>';
}
$('refreshBtn').addEventListener('click',render);render();
