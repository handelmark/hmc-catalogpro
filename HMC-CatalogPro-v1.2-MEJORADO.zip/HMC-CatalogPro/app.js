import { downloadCatalogPdf } from './catalog-pdf.js';
import { STORE,EVENTS,uid,esc,money,CURRENCIES,storageGet,storageSet,logEvent,initialWorkspace,downloadFile,fileStem,parseCsv,csvEscape,compressImage,safeWorkspace,localizeOldDemo } from './common.js';
const $=id=>document.getElementById(id);
let workspace;
let pendingProductImage='';let pendingLogo='';let saveTimer;let saveChain=Promise.resolve();let toastTimer;
function current(){return workspace.catalogs.find(c=>c.id===workspace.activeId)||workspace.catalogs[0]}
function notice(message){const t=$('toast');t.textContent=message;t.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.hidden=true,3200)}
function queueSave(){
  $('saveStatus').textContent='Guardando…';clearTimeout(saveTimer);
  saveTimer=setTimeout(()=>{const snapshot=JSON.parse(JSON.stringify(workspace));saveChain=saveChain.catch(()=>{}).then(async()=>{
    const ok=await storageSet(STORE,snapshot);$('saveStatus').textContent=ok?'Guardado en este navegador':'Almacenamiento lleno · descarga una copia de seguridad';if(!ok)notice('El almacenamiento del navegador está lleno. Exporta una copia antes de cerrar.');
  })},230);
}
function productCard(p,cls=''){
  const img=p.image?`<img loading="lazy" alt="${esc(p.name)}" src="${p.image}">`:`<span class="prod-placeholder">${esc(p.emoji||'◆')}</span>`;
  return `<article class="catalog-prod ${cls}"><div class="catalog-prod-image">${img}</div><div class="catalog-prod-body"><span class="catalog-category">${esc(p.category||'COLECCIÓN')}</span><b>${esc(p.name)}</b><p>${esc(p.description||p.sku||'')}</p><div class="catalog-prod-bottom"><strong>${esc(money(p.price,current().currency))}</strong>${p.sku?`<small>${esc(p.sku)}</small>`:''}</div></div></article>`;
}
function renderPreview(){const c=current();const paper=$('catalogPaper');paper.className=`catalog-paper theme-${c.theme||'violet'} layout-${c.layout||'cuadricula'}`;
  const logo=c.logo?`<img class="catalog-logo" src="${c.logo}" alt="Logo de ${esc(c.brand)}">`:`<span class="catalog-mark">${esc(c.brand||'TU MARCA').toUpperCase()}</span>`;
  paper.innerHTML=`<header class="catalog-cover"><div class="catalog-cover-orb"></div><div class="catalog-cover-brand">${logo}</div><span class="catalog-cover-eyebrow">CATÁLOGO DE PRODUCTOS</span><h2>${esc(c.title)}</h2><p>${esc(c.tagline||'Descubre nuestra colección')}</p></header><div class="catalog-note"><span>LA COLECCIÓN</span><span>${c.products.length} productos · ${esc(c.currency)}</span></div>${c.products.length?`<div class="catalog-grid">${c.products.map(p=>productCard(p)).join('')}</div>`:'<div class="empty"><b>Tu catálogo está vacío</b>Añade un producto para verlo aquí.</div>'}<footer class="catalog-foot"><span>${esc(c.contact||c.brand||'')}</span><span>HMC CatalogPro · 01</span></footer>`;
  document.querySelectorAll('.template-option').forEach(b=>{b.classList.toggle('active',b.dataset.theme===c.theme);b.setAttribute('aria-pressed',b.dataset.theme===c.theme)});
  $('layoutSelect').value=c.layout||'cuadricula';$('currencyQuick').value=c.currency;
}
function renderCatalogs(){const list=$('catalogList');list.replaceChildren();workspace.catalogs.forEach(c=>{
  const btn=document.createElement('button');btn.type='button';btn.className='catalog-item'+(c.id===workspace.activeId?' active':'');btn.textContent=`▤   ${c.title}`;btn.title=c.title;btn.onclick=()=>{workspace.activeId=c.id;queueSave();render();document.getElementById('sidebar').classList.remove('open')};list.append(btn);
})}
function render(){const c=current();$('catalogTitle').textContent=c.title;$('countProducts').textContent=c.products.length;
  $('countCategories').textContent=new Set(c.products.map(p=>p.category).filter(Boolean)).size;
  $('catalogValue').textContent=money(c.products.reduce((s,p)=>s+Number(p.price||0),0),c.currency);
  renderCatalogs();renderProducts();renderPreview();}
function renderProducts(){const c=current();const search=$('search').value.trim().toLowerCase();const category=$('categoryFilter').value;
  const cats=[...new Set(c.products.map(p=>p.category).filter(Boolean))].sort((a,b)=>a.localeCompare(b));$('categoryFilter').innerHTML='<option value="">Todas las categorías</option>'+cats.map(cat=>`<option value="${esc(cat)}">${esc(cat)}</option>`).join('');$('categoryFilter').value=cats.includes(category)?category:'';
  const shown=c.products.filter(p=>(!search||[p.name,p.sku,p.category,p.description].join(' ').toLowerCase().includes(search))&&(!category||p.category===category));
  $('productsBody').innerHTML=shown.map(p=>`<tr><td><div class="name-cell"><span class="thumb">${p.image?`<img src="${p.image}" alt="">`:esc(p.emoji||'◈')}</span><div><div class="product-name">${esc(p.name)}</div><div class="product-small">${esc(p.sku||p.category||'')}</div></div></div></td><td><strong>${esc(money(p.price,c.currency))}</strong></td><td><div class="row-actions"><button title="Editar producto" aria-label="Editar ${esc(p.name)}" data-act="edit" data-id="${esc(p.id)}">✎</button><button title="Duplicar producto" aria-label="Duplicar ${esc(p.name)}" data-act="dup" data-id="${esc(p.id)}">⊞</button><button title="Eliminar producto" aria-label="Eliminar ${esc(p.name)}" data-act="del" data-id="${esc(p.id)}">×</button></div></td></tr>`).join('')||'<tr><td colspan="3" class="empty"><b>No se encontraron productos</b>Añade un producto o importa una hoja de cálculo.</td></tr>';
}
function update(){queueSave();render()}
function showDialog(id){const d=$(id);if(!d.open)d.showModal()}
function closeDialog(id){$(id).close()}
function thumbPreview(id,image,text){$(id).innerHTML=image?`<img src="${image}" alt="Vista previa de la imagen">`:esc(text)}
function openProduct(p){
  $('productForm').reset();$('productDialogTitle').textContent=p?'Editar producto':'Añadir producto';$('productId').value=p?.id||'';
  $('productName').value=p?.name||'';$('productPrice').value=p?.price??'';$('productCategory').value=p?.category||'';
  $('productSku').value=p?.sku||'';$('productDescription').value=p?.description||'';pendingProductImage=p?.image||'';
  thumbPreview('productImagePreview',pendingProductImage,'Haz clic para subir JPG, PNG o WebP');$('productCurrencyLabel').textContent=`(${current().currency})`;showDialog('productDialog');$('productName').focus();
}
function openBrand(){const c=current();$('brandTitle').value=c.title;$('brandName').value=c.brand;$('brandTagline').value=c.tagline;$('brandCurrency').value=c.currency;$('brandContact').value=c.contact;pendingLogo=c.logo||'';thumbPreview('logoPreview',pendingLogo,'Sube tu logo');showDialog('brandDialog')}
function addCatalog(){const title=prompt('Nombre de tu nuevo catálogo:','Mi nueva colección');if(title===null)return;const id=uid();workspace.catalogs.push({id,title:title.trim().slice(0,100)||'Colección sin título',brand:'Mi tienda',tagline:'Descubre nuestros productos',contact:'',currency:'USD',logo:'',theme:'violet',layout:'cuadricula',products:[],createdAt:new Date().toISOString()});workspace.activeId=id;update();logEvent('catalog_created',current().title);notice('Nuevo catálogo creado')}
function duplicateCatalog(){if(workspace.catalogs.length>=100)return notice('Se alcanzó el máximo de 100 catálogos');const c=JSON.parse(JSON.stringify(current()));c.id=uid();c.title=`${c.title} (copia)`;c.products=c.products.map(p=>({...p,id:uid()}));workspace.catalogs.push(c);workspace.activeId=c.id;update();logEvent('catalog_duplicated',c.title);notice('Catálogo duplicado')}
function deleteCatalog(){if(workspace.catalogs.length===1)return notice('Debes conservar al menos un catálogo. Puedes eliminar sus productos por separado.');const c=current();if(!confirm(`¿Eliminar «${c.title}» y sus ${c.products.length} productos? Esta acción no se puede deshacer.`))return;workspace.catalogs=workspace.catalogs.filter(x=>x.id!==c.id);workspace.activeId=workspace.catalogs[0].id;update();logEvent('catalog_deleted',c.title);notice('Catálogo eliminado')}
function priceOrZero(v){const x=Number(v);return Number.isFinite(x)?Math.min(999999999,Math.max(0,x)):0}
function normalizedKey(v){return String(v||'').trim().toLowerCase().replace(/[\s_\-\/]/g,'')}
function importedRows(rows){
  if(!Array.isArray(rows)||rows.length<2)throw new Error('La hoja debe tener encabezados y al menos un producto.');
  const headers=rows[0].map(normalizedKey);const idx=(...keys)=>headers.findIndex(h=>keys.includes(h));
  const ni=idx('name','product','productname','item','nombre','producto','nombreproducto','articulo','artículo');
  const pi=idx('price','unitprice','saleprice','precio','preciounitario','cost','value');
  const ci=idx('category','categoria','categoría','type','collection');
  const si=idx('sku','code','reference','referencia','codigo','código','id');
  const di=idx('description','descripcion','descripción','details','detalle');
  if(ni<0||pi<0)throw new Error('Faltan las columnas obligatorias: nombre y precio. Descarga el CSV de ejemplo.');
  const products=[];
  for(const row of rows.slice(1)){
    const name=String(row[ni]??'').trim();if(!name)continue;
    let raw=String(row[pi]??'').trim().replace(/\s/g,'');
    // Accept 1299.50 / 1299,50 / $1,299.50 / 1.299,50
    raw=raw.replace(/[^0-9,.-]/g,'');if(raw.includes(',')&&raw.includes('.'))raw=raw.lastIndexOf(',')>raw.lastIndexOf('.')?raw.replace(/\./g,'').replace(',','.'):raw.replace(/,/g,'');else if(raw.includes(','))raw=raw.replace(',','.');
    const parsed=Number(raw);if(!Number.isFinite(parsed)||parsed<0)continue;
    products.push({id:uid(),name:name.slice(0,120),price:priceOrZero(parsed),category:ci>=0?String(row[ci]??'').slice(0,60):'',sku:si>=0?String(row[si]??'').slice(0,60):'',description:di>=0?String(row[di]??'').slice(0,500):'',image:'',emoji:'◈'});
  }
  if(!products.length)throw new Error('No se encontraron productos válidos. Revisa los nombres y precios.');return products;
}
async function importProducts(){const file=$('importFile').files?.[0];if(!file)return notice('Primero selecciona un archivo CSV o XLSX.');if(file.size>8*1024*1024)return notice('El tamaño máximo permitido es de 8 MB.');const btn=$('doImport');btn.disabled=true;
  try{
    let rows;if(/\.csv$/i.test(file.name)){rows=parseCsv(await file.text())}
    else if(/\.xlsx?$/i.test(file.name)){if(!window.XLSX)throw new Error('No se pudo cargar la biblioteca para Excel. Conéctate a internet o utiliza CSV.');const book=window.XLSX.read(await file.arrayBuffer(),{type:'array'});rows=window.XLSX.utils.sheet_to_json(book.Sheets[book.SheetNames[0]],{header:1,defval:''});}
    else throw new Error('Formatos admitidos: .csv, .xlsx y .xls');
    const items=importedRows(rows);if(current().products.length+items.length>5000)throw new Error('El máximo es de 5.000 productos por catálogo.');
    current().products.push(...items);$('importFile').value='';update();closeDialog('importDialog');logEvent('csv_imported',`${items.length} productos · ${file.name}`);notice(`Se importaron ${items.length} productos`);
  }catch(e){notice(e.message||'No se pudo importar el archivo')}finally{btn.disabled=false}
}
function exportCsv(){const c=current();const rows=[['nombre','precio','categoria','sku','descripcion'],...c.products.map(p=>[p.name,p.price,p.category,p.sku,p.description])];downloadFile(`${fileStem(c.title)}.csv`,rows.map(r=>r.map(csvEscape).join(',')).join('\r\n'),'text/csv;charset=utf-8');logEvent('csv_exported',c.title);notice('CSV exportado')}
function exportHtml(){
  const c=current(),name=esc(c.title);
  const tones={violet:['#6655f5','#181d3d','#f1efff'],bold:['#f26047','#202337','#fff0e9'],forest:['#208967','#143e38','#e8f7f0'],slate:['#4266a3','#182d4e','#ebf1fa']};
  const [accent,deep,tint]=tones[c.theme]||tones.violet;
  const magazine=c.layout==='revista';
  const items=c.products.map(p=>`<article class="item"><div class="photo">${p.image?`<img src="${p.image}" alt="${esc(p.name)}">`:`<span>${esc(p.emoji||'◆')}</span>`}</div><div class="detail"><small class="category">${esc(p.category||'COLECCIÓN')}</small><h3>${esc(p.name)}</h3><p>${esc(p.description||'')}</p><div class="bottom"><strong>${esc(money(p.price,c.currency))}</strong><small>${esc(p.sku||'')}</small></div></div></article>`).join('');
  const styles=`:root{--accent:${accent};--deep:${deep};--tint:${tint};font-family:system-ui,-apple-system,'Segoe UI',sans-serif;color:#20263b}*{box-sizing:border-box}body{margin:0;background:#eceff6}.wrap{max-width:1000px;margin:30px auto;background:#f7f8fb;box-shadow:0 15px 40px #12182a15}.cover{position:relative;background:var(--deep);color:white;padding:44px 46px 52px;overflow:hidden}.cover:after{content:'';position:absolute;border-radius:50%;width:300px;height:300px;background:var(--accent);right:-85px;top:-125px;pointer-events:none}.cover .brand{position:relative;z-index:1;font-size:14px;font-weight:850;letter-spacing:2px}.cover img{display:block;position:relative;z-index:1;max-width:160px;max-height:60px;object-fit:contain;background:white;padding:7px;border-radius:8px}.cover .eyebrow{display:block;position:relative;z-index:1;margin-top:46px;font-size:11px;letter-spacing:2px;color:#c4c1ff;font-weight:850}.cover h1{position:relative;z-index:1;font-size:clamp(34px,5vw,58px);line-height:1.04;margin:10px 0 12px;max-width:85%;overflow-wrap:anywhere}.cover p{position:relative;z-index:1;color:#d4d9ed;font-size:15px;max-width:75%;overflow-wrap:anywhere}.headline{display:flex;justify-content:space-between;gap:10px;padding:30px 39px 16px;color:#74829a;font-weight:850;letter-spacing:1.2px;font-size:11px}.headline span:last-child{color:var(--accent)}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px;padding:0 36px 30px}.item{background:white;border:1px solid #e6eaf1;border-radius:14px;overflow:hidden;break-inside:avoid}.photo{height:210px;margin:12px 12px 0;display:grid;place-items:center;border-radius:10px;background:var(--tint);font-size:70px;overflow:hidden}.photo img{width:100%;height:100%;object-fit:contain}.detail{padding:18px 18px 21px;display:flex;flex-direction:column}.category{font-size:10px;font-weight:850;letter-spacing:1px;color:var(--accent);text-transform:uppercase}.detail h3{font-size:21px;margin:8px 0;overflow-wrap:anywhere}.detail p{font-size:13px;line-height:1.5;color:#7d8a9e;min-height:20px;overflow-wrap:anywhere}.bottom{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-top:12px}.bottom strong{color:var(--accent);font-size:23px}.bottom small{color:#a0abbc;font-size:10px}.footer{margin:0 36px;border-top:1px solid #dfe5ed;padding:20px 0 28px;display:flex;justify-content:space-between;gap:10px;color:#8b98aa;font-size:12px}.grid.magazine{grid-template-columns:1fr}.grid.magazine .item{display:grid;grid-template-columns:42% 1fr;min-height:240px}.grid.magazine .photo{height:auto;margin:12px 0 12px 12px}.grid.magazine .detail{padding:33px 25px}.grid.magazine .detail h3{font-size:27px}@media(max-width:650px){.wrap{margin:0}.cover{padding:32px 20px}.cover h1{max-width:100%;font-size:36px}.headline{padding:20px 14px 12px}.grid{padding:0 11px 20px;gap:9px}.item{border-radius:9px}.photo{height:110px;margin:6px 6px 0}.detail{padding:10px}.detail h3{font-size:14px}.detail p{font-size:10px}.bottom strong{font-size:14px}.footer{margin:0 13px}.grid.magazine .item{min-height:165px}.grid.magazine .detail{padding:14px}.grid.magazine .detail h3{font-size:17px}}@media print{body{background:white}.wrap{box-shadow:none;margin:0;max-width:none}.cover,.photo{print-color-adjust:exact;-webkit-print-color-adjust:exact}.item{box-shadow:none}@page{size:A4;margin:8mm}}`;
  const html=`<!doctype html><html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${name}</title><style>${styles}</style></head><body><main class="wrap"><section class="cover">${c.logo?`<img src="${c.logo}" alt="Logo">`:`<div class="brand">${esc(c.brand||'TU MARCA').toUpperCase()}</div>`}<span class="eyebrow">CATÁLOGO DE PRODUCTOS</span><h1>${name}</h1><p>${esc(c.tagline||'Descubre nuestra colección')}</p></section><div class="headline"><span>LA COLECCIÓN</span><span>${c.products.length} productos · ${esc(c.currency)}</span></div><div class="grid ${magazine?'magazine':''}">${items}</div><div class="footer"><span>${esc(c.contact||c.brand||'')}</span><span>Creado con HMC CatalogPro</span></div></main></body></html>`;
  downloadFile(`${fileStem(c.title)}.html`,html,'text/html;charset=utf-8');logEvent('html_exported',c.title);notice('Catálogo HTML descargado para compartir');
}
async function printCatalog(){
  const btn=$('printBtn'),c=current();if(btn.disabled)return;
  btn.disabled=true;btn.textContent='⏳ Preparando PDF…';
  try{
    const result=await downloadCatalogPdf(c,(page,total)=>{btn.textContent=`Preparando PDF ${page}/${total}…`});
    logEvent('pdf_exported',`${c.title} · ${result.pages} páginas`);
    notice(`PDF descargado (${result.pages} ${result.pages===1?'página':'páginas'})`);
  }catch(e){console.error(e);notice(e.message||'No se pudo crear el PDF')}
  finally{btn.disabled=false;btn.textContent='↓ Descargar PDF'}
}
async function exportBackup(){const snapshot=JSON.stringify(workspace,null,2);downloadFile(`hmc-catalogpro-backup-${new Date().toISOString().slice(0,10)}.json`,snapshot,'application/json;charset=utf-8');logEvent('backup_exported',`${workspace.catalogs.length} catálogos`);notice('Copia de seguridad descargada')}
async function restoreBackup(e){const file=e.target.files?.[0];if(!file)return;if(file.size>60*1024*1024){notice('La copia es demasiado grande (máximo 60 MB)');return}try{const data=safeWorkspace(JSON.parse(await file.text()));if(!confirm('¿Reemplazar todos los catálogos guardados en este navegador con esta copia?'))return;workspace=data;queueSave();render();closeDialog('backupDialog');logEvent('backup_restored',`${data.catalogs.length} catálogos`);notice('Copia de seguridad restaurada')}catch(err){notice(err.message||'No se pudo restaurar la copia')}finally{e.target.value=''}}
async function setup(){
  workspace=await storageGet(STORE);if(!workspace){workspace=initialWorkspace();await storageSet(STORE,workspace)}else{try{workspace=safeWorkspace(workspace)}catch{workspace=initialWorkspace();notice('Los datos anteriores no eran válidos; se cargó una demostración nueva.')}}
  if(localizeOldDemo(workspace))await storageSet(STORE,workspace);
  logEvent('app_open',current().title);
  document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>closeDialog(b.dataset.close)));
  document.querySelectorAll('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d)d.close()}));
  $('toggleMenu').onclick=()=>document.getElementById('sidebar').classList.toggle('open');
  const currencyLabels={USD:'Dólar estadounidense',EUR:'Euro',GBP:'Libra esterlina',PEN:'Sol peruano',MXN:'Peso mexicano',BRL:'Real brasileño',COP:'Peso colombiano',CAD:'Dólar canadiense',AUD:'Dólar australiano',ARS:'Peso argentino',CLP:'Peso chileno',UYU:'Peso uruguayo',PYG:'Guaraní paraguayo',BOB:'Boliviano',CRC:'Colón costarricense',DOP:'Peso dominicano',GTQ:'Quetzal',HNL:'Lempira',NIO:'Córdoba',VES:'Bolívar venezolano',JPY:'Yen japonés',CNY:'Yuan chino',KRW:'Won surcoreano',INR:'Rupia india',CHF:'Franco suizo',SEK:'Corona sueca',NOK:'Corona noruega',DKK:'Corona danesa',PLN:'Zloty polaco',TRY:'Lira turca',ZAR:'Rand sudafricano',AED:'Dírham emiratí',SAR:'Riyal saudí',SGD:'Dólar singapurense',HKD:'Dólar de Hong Kong',NZD:'Dólar neozelandés'};
  for(const id of ['brandCurrency','currencyQuick']){
    $(id).innerHTML=CURRENCIES.map(code=>`<option value="${code}">${code} · ${esc(currencyLabels[code]||code)}</option>`).join('');
  }
  render();
  $('layoutSelect').onchange=e=>{current().layout=e.target.value;update();logEvent('layout_changed',e.target.value)};
  $('currencyQuick').onchange=e=>{current().currency=e.target.value;update();logEvent('currency_changed',e.target.value);notice(`Moneda cambiada a ${e.target.value}. Los importes no se convierten.`)};
  $('newCatalog').onclick=addCatalog;$('addProduct').onclick=()=>openProduct(null);$('brandBtn').onclick=openBrand;$('importBtn').onclick=()=>showDialog('importDialog');$('backupBtn').onclick=()=>showDialog('backupDialog');$('printBtn').onclick=printCatalog;
  $('search').oninput=renderProducts;$('categoryFilter').onchange=renderProducts;
  $('duplicateCatalog').onclick=duplicateCatalog;$('deleteCatalog').onclick=deleteCatalog;$('exportCsv').onclick=exportCsv;$('exportHtml').onclick=exportHtml;
  $('downloadBackup').onclick=exportBackup;$('restoreInput').onchange=restoreBackup;$('doImport').onclick=importProducts;
  $('templateOptions').addEventListener('click',e=>{const b=e.target.closest('[data-theme]');if(!b)return;current().theme=b.dataset.theme;update();logEvent('theme_changed',b.dataset.theme)});
  $('productsBody').addEventListener('click',e=>{
    const b=e.target.closest('[data-act]');if(!b)return;const p=current().products.find(x=>x.id===b.dataset.id);if(!p)return;
    if(b.dataset.act==='edit')openProduct(p);
    if(b.dataset.act==='dup'){if(current().products.length>=5000)return notice('El catálogo está lleno');const copy={...p,id:uid(),name:`${p.name} (copia)`};current().products.push(copy);update();logEvent('product_added',copy.name);notice('Producto duplicado')}
    if(b.dataset.act==='del'&&confirm(`¿Eliminar «${p.name}»?`)){current().products=current().products.filter(x=>x.id!==p.id);update();logEvent('product_deleted',p.name);notice('Producto eliminado')}
  });
  $('productImage').addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;try{pendingProductImage=await compressImage(f);thumbPreview('productImagePreview',pendingProductImage,'Subir foto')}catch(err){notice(err.message)}finally{e.target.value=''}});
  $('removeProductImage').onclick=()=>{pendingProductImage='';thumbPreview('productImagePreview','','Haz clic para subir JPG, PNG o WebP')};
  $('productForm').addEventListener('submit',e=>{e.preventDefault();const id=$('productId').value;const name=$('productName').value.trim();if(!name)return;const item={id:id||uid(),name,price:priceOrZero($('productPrice').value),category:$('productCategory').value.trim(),sku:$('productSku').value.trim(),description:$('productDescription').value.trim(),image:pendingProductImage,emoji:'◈'};
    if(id){const index=current().products.findIndex(p=>p.id===id);if(index>=0)current().products[index]=item;logEvent('product_updated',name)}else{if(current().products.length>=5000)return notice('El catálogo está lleno');current().products.push(item);logEvent('product_added',name)}
    update();closeDialog('productDialog');notice(id?'Producto actualizado':'Producto añadido');
  });
  $('brandLogo').addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;try{pendingLogo=await compressImage(f,430);thumbPreview('logoPreview',pendingLogo,'Subir logo')}catch(err){notice(err.message)}finally{e.target.value=''}});
  $('removeLogo').onclick=()=>{pendingLogo='';thumbPreview('logoPreview','','Sube tu logo')};
  $('brandForm').addEventListener('submit',e=>{e.preventDefault();const c=current();c.title=$('brandTitle').value.trim()||'Sin título';c.brand=$('brandName').value.trim();c.tagline=$('brandTagline').value.trim();c.currency=$('brandCurrency').value;c.contact=$('brandContact').value.trim();c.logo=pendingLogo;update();closeDialog('brandDialog');logEvent('brand_updated',c.title);notice('Marca actualizada')});
  $('resetDemo').onclick=async e=>{e.preventDefault();if(!confirm('¿Restablecer los catálogos de demostración? Se perderán los datos guardados en este navegador. Descarga una copia antes si lo necesitas.'))return;workspace=initialWorkspace();update();$('search').value='';notice('Demostración restablecida')};
  document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();queueSave();notice('Guardando cambios')}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();$('search').focus()}});
}
setup().catch(e=>{console.error(e);notice('No se pudo iniciar la aplicación. Prueba a actualizar la página.')});
