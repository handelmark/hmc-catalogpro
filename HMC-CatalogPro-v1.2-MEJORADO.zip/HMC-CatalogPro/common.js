export const STORE = 'hmc_catalogpro_workspace_v1';
export const EVENTS = 'hmc_apps_local_events_v1';
export const uid = () => (globalThis.crypto?.randomUUID?.() || `hmc-${Date.now()}-${Math.random().toString(36).slice(2)}`);
export const CURRENCIES = ['USD','EUR','GBP','PEN','MXN','BRL','COP','CAD','AUD','ARS','CLP','UYU','PYG','BOB','CRC','DOP','GTQ','HNL','NIO','VES','JPY','CNY','KRW','INR','CHF','SEK','NOK','DKK','PLN','TRY','ZAR','AED','SAR','SGD','HKD','NZD'];
const clone = v => JSON.parse(JSON.stringify(v));
let dbPromise;
function db(){
  if(!('indexedDB' in window)) return Promise.reject(new Error('IndexedDB not available'));
  if(!dbPromise) dbPromise = new Promise((resolve,reject)=>{
    const req = indexedDB.open('HMC_Apps_Local',1);
    req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains('kv'))req.result.createObjectStore('kv')};
    req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);
  });
  return dbPromise;
}
async function idbGet(key){const d=await db();return new Promise((resolve,reject)=>{const t=d.transaction('kv','readonly');const r=t.objectStore('kv').get(key);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function idbPut(key,val){const d=await db();return new Promise((resolve,reject)=>{const t=d.transaction('kv','readwrite');t.objectStore('kv').put(val,key);t.oncomplete=()=>resolve();t.onerror=()=>reject(t.error)})}
export async function storageGet(key){try{return await idbGet(key)}catch{try{return JSON.parse(localStorage.getItem(key))}catch{return null}}}
export async function storageSet(key,val){try{await idbPut(key,val);return true}catch{try{localStorage.setItem(key,JSON.stringify(val));return true}catch{return false}}}
export function esc(value){return String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
export function money(value,currency='USD'){try{return new Intl.NumberFormat('es-PE',{style:'currency',currency}).format(Number(value)||0)}catch{return `${currency} ${(Number(value)||0).toFixed(2)}`}}
export async function logEvent(action,details=''){
  try{const events=(await storageGet(EVENTS))||[];events.unshift({id:uid(),type:action,details,time:new Date().toISOString()});await storageSet(EVENTS,events.slice(0,500))}catch(e){console.warn('Analytics local event unavailable',e)}
}
export function initialWorkspace(){const products=[
  ['Reloj clásico',49,'Accesorios','W-101','Diseño minimalista para todos los días','⌚'],
  ['Mochila urbana',69,'Mochilas y bolsos','B-202','Mochila ligera y resistente','🎒'],
  ['Audífonos de estudio',89,'Electrónica','H-303','Escucha música sin cables donde quieras','🎧'],
  ['Botella térmica',24.5,'Hogar y estilo de vida','L-404','Botella reutilizable que conserva la temperatura','🥤'],
  ['Bolsa de tela',19,'Mochilas y bolsos','B-405','Bolsa reutilizable para el día a día','👜'],
  ['Lámpara de escritorio',39,'Hogar y estilo de vida','L-406','Luz suave para trabajar y estudiar','💡']
].map(p=>({id:uid(),name:p[0],price:p[1],category:p[2],sku:p[3],description:p[4],emoji:p[5],image:''}));
const id=uid();return {version:1,activeId:id,catalogs:[{id,title:'Colección de verano 2026',brand:'North Studio',tagline:'Productos seleccionados para tu día a día.',contact:'northstudio.example',currency:'USD',logo:'',theme:'violet',layout:'cuadricula',products,createdAt:new Date().toISOString()}]};}
export function downloadFile(name,content,mime='text/plain;charset=utf-8'){
  const blob=new Blob([content],{type:mime});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000)
}
export function fileStem(value){return String(value||'catalogo').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9\s-]/g,'').trim().replace(/\s+/g,'-').slice(0,60)||'catalogo'}
export function parseCsv(text){
  const out=[];let row=[],cell='',inQuotes=false;
  text=String(text).replace(/^\uFEFF/,'');
  for(let i=0;i<text.length;i++){
    const c=text[i];if(c==='"'){if(inQuotes && text[i+1]==='"'){cell+='"';i++}else inQuotes=!inQuotes}
    else if(c===',' && !inQuotes){row.push(cell);cell=''}
    else if((c==='\n'||c==='\r')&&!inQuotes){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cell);if(row.some(x=>x.trim()))out.push(row);row=[];cell=''}
    else cell+=c;
  }
  if(inQuotes)throw new Error('El CSV contiene comillas sin cerrar.');
  row.push(cell);if(row.some(x=>x.trim()))out.push(row);
  return out;
}
export function csvEscape(v){const s=String(v??'');return /[",\r\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s}
export async function compressImage(file,maxSide=820){
  if(!file?.type?.startsWith('image/'))throw new Error('Selecciona una imagen válida.');
  if(file.size>15*1024*1024)throw new Error('El tamaño máximo de la imagen es 15 MB.');
  const img=await new Promise((resolve,reject)=>{const u=URL.createObjectURL(file),im=new Image();im.onload=()=>{URL.revokeObjectURL(u);resolve(im)};im.onerror=()=>{URL.revokeObjectURL(u);reject(new Error('No se pudo leer la imagen.'))};im.src=u});
  const scale=Math.min(1,maxSide/Math.max(img.width,img.height));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));const context=canvas.getContext('2d');
  if(!context)throw new Error('Tu navegador no permite editar imágenes.');
  // PNG or WebP with alpha retains a transparent background.
  const type=file.type==='image/png'||file.type==='image/webp'?'image/webp':'image/jpeg';
  context.drawImage(img,0,0,canvas.width,canvas.height);return canvas.toDataURL(type,.78);
}
export function safeWorkspace(obj){
  if(!obj||typeof obj!=='object'||!Array.isArray(obj.catalogs)||!obj.catalogs.length||obj.catalogs.length>100)throw new Error('Copia no válida: deben existir entre 1 y 100 catálogos.');
  const catalogs=obj.catalogs.map(c=>{
    if(!c||typeof c!=='object'||!Array.isArray(c.products)||c.products.length>5000)throw new Error('Se encontró un catálogo inválido en la copia.');
    return {id:String(c.id||uid()),title:String(c.title||'Sin título').slice(0,100),brand:String(c.brand||'').slice(0,100),tagline:String(c.tagline||'').slice(0,170),contact:String(c.contact||'').slice(0,120),currency:CURRENCIES.includes(c.currency)?c.currency:'USD',layout:['cuadricula','revista'].includes(c.layout)?c.layout:'cuadricula',logo:typeof c.logo==='string'&&/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/i.test(c.logo)?c.logo:'',theme:['violet','bold','forest','slate'].includes(c.theme)?c.theme:'violet',createdAt:c.createdAt||new Date().toISOString(),products:c.products.map(p=>({id:String(p.id||uid()),name:String(p.name||'Producto').slice(0,120),price:Math.max(0,Math.min(Number(p.price)||0,999999999)),category:String(p.category||'Otros').slice(0,60),sku:String(p.sku||'').slice(0,60),description:String(p.description||'').slice(0,500),emoji:String(p.emoji||'◈').slice(0,4),image:typeof p.image==='string'&&/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/i.test(p.image)?p.image:''}))}
  });
  return {version:1,catalogs,activeId:catalogs.some(c=>c.id===obj.activeId)?obj.activeId:catalogs[0].id};
}

// Solo traduce los datos de muestra de la versión anterior; conserva los datos personalizados.
export function localizeOldDemo(workspace){
  if(!workspace?.catalogs)return false;
  const values=new Map([
    ['Everyday Watch',['Reloj clásico','Accessories','Accesorios','Minimal everyday design','Diseño minimalista para todos los días']],
    ['Urban Backpack',['Mochila urbana','Bags','Mochilas y bolsos','Lightweight and durable backpack','Mochila ligera y resistente']],
    ['Studio Headphones',['Audífonos de estudio','Electronics','Electrónica','Wireless music wherever you go','Escucha música sin cables donde quieras']],
    ['Classic Bottle',['Botella térmica','Lifestyle','Hogar y estilo de vida','Insulated reusable drink bottle','Botella reutilizable que conserva la temperatura']],
    ['Canvas Tote',['Bolsa de tela','Bags','Mochilas y bolsos','Everyday reusable tote','Bolsa reutilizable para el día a día']],
    ['Desk Lamp',['Lámpara de escritorio','Lifestyle','Hogar y estilo de vida','Soft light for your creative space','Luz suave para trabajar y estudiar']]
  ]);
  let changed=false;
  for(const c of workspace.catalogs){
    if(c.title==='Summer Collection 2026'){c.title='Colección de verano 2026';changed=true}
    if(c.tagline==='Everyday objects. Thoughtfully selected.'){c.tagline='Productos seleccionados para tu día a día.';changed=true}
    for(const p of c.products||[]){const data=values.get(p.name);if(!data)continue;
      p.name=data[0];changed=true;
      if(p.category===data[1])p.category=data[2];
      if(p.description===data[3])p.description=data[4];
    }
  }
  return changed;
}
