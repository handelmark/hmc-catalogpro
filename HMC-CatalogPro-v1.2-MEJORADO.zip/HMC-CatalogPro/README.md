# HMC CatalogPro — v1.2 (español)

Primera microaplicación experimental de **HMC Apps**, con tres pantallas independientes:

- `index.html`: página de presentación y venta (*landing page*).
- `app.html`: editor de catálogos de productos.
- `admin.html`: panel local de demostración. **No registra pagos reales** ni está protegido por un sistema de autenticación.

## Iniciar en Windows

1. Descomprime el ZIP completo. No abras archivos desde WinRAR.
2. Si tienes Node.js instalado, haz doble clic en `START-WINDOWS.bat`.
3. Abre `http://localhost:8080` si el servidor no lo hace automáticamente.
4. Alternativamente, conéctate a Netlify Drop y publica la carpeta entera. Necesitas una web servida por HTTP para los módulos JavaScript.

## Novedades de la versión 1.2

- **Descarga PDF directa**: crea un archivo `.pdf` real en la carpeta de descargas sin abrir el cuadro de impresión. Exportación A4 multipágina, hasta 500 productos por PDF; funciona sin servicios externos. **Nota:** las páginas son imágenes de alta resolución incorporadas en el PDF, por lo que el texto no es seleccionable ni buscable.
- **Diseño actualizado**: portada mejorada, fotografías, categorías, información de referencia, precios y pies de página con mejor jerarquía visual.
- **Dos presentaciones**: *Cuadrícula elegante* y *Estilo revista*.
- **36 monedas disponibles** para todo el catálogo, entre ellas USD, PEN, EUR, MXN, COP, ARS, CLP, BRL, GBP, JPY e INR. El selector modifica el formato y símbolo; **no hace conversiones de tipo de cambio**.
- Los formatos y monedas nuevos se guardan en el catálogo y en las copias JSON. Los catálogos anteriores siguen siendo compatibles.
- La exportación HTML y CSV continúan disponibles.

## Cómo probar el PDF

1. Abre `app.html` desde el servidor.
2. Selecciona el catálogo de ejemplo con sus seis productos.
3. En **Diseño**, elige Cuadrícula o Revista; cambia la moneda en **Moneda**.
4. Haz clic en **Descargar PDF** (arriba a la derecha).
5. El archivo se descargará con el nombre de tu catálogo. Ábrelo en Chrome o en un lector PDF.

## Datos y seguridad

Los catálogos quedan guardados **solo en ese navegador y dispositivo** mediante IndexedDB o localStorage. Descarga copias de seguridad JSON si tus datos importan. Cambiar de navegador, limpiar el almacenamiento o usar otro dispositivo no sincroniza los datos. Todavía no existe sistema de pagos, usuarios, licencias ni analítica remota.

La lectura XLSX se apoya en una biblioteca externa; si no tienes internet, importa CSV. Exportar PDF funciona sin esa biblioteca ni conexión.

## Próximas fases comerciales

1. Investigación de mercado y validación de compradores.
2. Inicio de sesión y almacenamiento central seguro.
3. Procesador de pagos compatible con vendedores desde Perú y clientes globales.
4. Licencias, límites de prueba y activación basada en confirmación de cobro.
5. Panel privado de ventas y estadísticas reales.

**No se debe publicar el panel `admin.html` como administración segura ni presentar los importes que muestre como ventas reales.**
