import { logEvent } from './common.js';
logEvent('landing_view','Página de venta de CatalogPro abierta');
