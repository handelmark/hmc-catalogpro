@echo off
title HMC CatalogPro - Vista previa local
where node >nul 2>nul
if errorlevel 1 (
  echo No se encontro Node.js. Instala Node.js desde https://nodejs.org/ o publica la carpeta en Netlify.
  pause
  exit /b 1
)
start "" "http://localhost:8080"
node server.js
pause
