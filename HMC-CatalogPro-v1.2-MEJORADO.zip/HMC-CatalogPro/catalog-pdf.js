// Exportador PDF autónomo: descarga un PDF real sin impresión ni bibliotecas externas.
// Cada página se rasteriza a 150 ppp aprox. y se incrusta como JPEG en un PDF A4.
import { money, fileStem, downloadFile } from './common.js';
const WIDTH = 1240, HEIGHT = 1754;
const themes = {
  violet:{accent:'#6655F5',dark:'#181D3D',pale:'#F1EFFF',soft:'#A9A3FF'},
  bold:{accent:'#F26047',dark:'#202337',pale:'#FFF0E9',soft:'#FFB9A6'},
  forest:{accent:'#208967',dark:'#143E38',pale:'#E8F7F0',soft:'#A1E5C7'},
  slate:{accent:'#4266A3',dark:'#182D4E',pale:'#EBF1FA',soft:'#ACC7E8'},
};
const font=(weight,size)=>`${weight} ${size}px system-ui, -apple-system, 'Segoe UI', Arial, sans-serif`;
function round(ctx,x,y,w,h,r,fill,stroke){ctx.beginPath();ctx.roundRect(x,y,w,h,r);if(fill){ctx.fillStyle=fill;ctx.fill()}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=2;ctx.stroke()}}
function write(ctx,text,x,y,maxWidth,{weight=500,size=24,color='#20263B',lines=1,lineHeight=1.25}={}){
 ctx.font=font(weight,size);ctx.fillStyle=color;ctx.textBaseline='top';
 const words=String(text||'').split(/\s+/).filter(Boolean),out=[];let line='';
 for(const word of words){const next=line?`${line} ${word}`:word;if(ctx.measureText(next).width>maxWidth&&line){out.push(line);line=word}else line=next}
 if(line)out.push(line);
 for(let i=0;i<Math.min(lines,out.length);i++){
  let s=out[i];if(i===lines-1&&out.length>lines){while(s.length&&ctx.measureText(s+'…').width>maxWidth)s=s.slice(0,-1);s+='…'}
  while(s.length&&ctx.measureText(s).width>maxWidth)s=s.slice(0,-1);ctx.fillText(s,x,y+i*size*lineHeight)
 }
 return Math.min(lines,out.length)*size*lineHeight;
}
function loadImg(src){return new Promise(resolve=>{if(!src||!src.startsWith('data:image/'))return resolve(null);const im=new Image();im.onload=()=>resolve(im);im.onerror=()=>resolve(null);im.src=src})}
function imageFit(ctx,image,x,y,w,h){if(!image)return;const ratio=Math.min(w/image.width,h/image.height);const iw=image.width*ratio,ih=image.height*ratio;ctx.drawImage(image,x+(w-iw)/2,y+(h-ih)/2,iw,ih)}
function hexToRgb(hex){return [parseInt(hex.slice(1,3),16),parseInt(hex.slice(3,5),16),parseInt(hex.slice(5,7),16)]}
function header(ctx,c,t,first,logo){
 const height=first?337:245;
 ctx.fillStyle=t.dark;ctx.fillRect(0,0,WIDTH,height);
 ctx.fillStyle=t.accent;ctx.beginPath();ctx.arc(WIDTH-115,6,216,0,Math.PI*2);ctx.fill();
 ctx.globalAlpha=.13;ctx.strokeStyle='#fff';ctx.lineWidth=45;ctx.beginPath();ctx.arc(WIDTH-10,180,155,0,Math.PI*2);ctx.stroke();ctx.globalAlpha=1;
 if(logo){round(ctx,70,52,145,83,15,'#FFFFFF');imageFit(ctx,logo,84,65,117,58)}
 else{write(ctx,(c.brand||'TU MARCA').toUpperCase(),72,59,720,{weight:800,size:26,color:'#FFFFFF',lines:1})}
 write(ctx,'CATÁLOGO DE PRODUCTOS',72,first?139:95,850,{weight:700,size:18,color:t.soft,lines:1});
 write(ctx,c.title,72,first?173:129,1010,{weight:800,size:first?65:49,color:'#FFFFFF',lines:2,lineHeight:1.04});
 if(first&&c.tagline)write(ctx,c.tagline,74,278,980,{size:21,color:'#D4D9EF',lines:1});
}
function card(ctx,p,img,x,y,w,h,t,c,layout){
 round(ctx,x,y,w,h,22,'#FFFFFF','#E7EAF2');
 const horizontal=layout==='revista';
 const photoX=x+15,photoY=y+15, photoW=horizontal?340:w-30,photoH=horizontal?h-30:211;
 round(ctx,photoX,photoY,photoW,photoH,16,t.pale);
 if(img){ctx.save();ctx.beginPath();ctx.roundRect(photoX,photoY,photoW,photoH,16);ctx.clip();imageFit(ctx,img,photoX+10,photoY+10,photoW-20,photoH-20);ctx.restore()}
 else{ctx.textBaseline='middle';ctx.textAlign='center';ctx.font=font(400,horizontal?79:80);ctx.fillStyle=t.accent;ctx.fillText(String(p.emoji||'◆'),photoX+photoW/2,photoY+photoH/2);ctx.textAlign='left';ctx.textBaseline='top'}
 const tx=horizontal?photoX+photoW+28:x+24,contentW=horizontal?w-photoW-72:w-48;
 const ty=horizontal?y+35:photoY+photoH+16;
 if(p.category)write(ctx,p.category.toUpperCase(),tx,ty,contentW,{weight:800,size:14,color:t.accent});
 write(ctx,p.name,tx,ty+(p.category?27:0),contentW,{weight:750,size:horizontal?31:24,lines:2,lineHeight:1.08});
 if(horizontal&&p.description)write(ctx,p.description,tx,ty+104,contentW,{size:19,color:'#78859A',lines:2});
 const price=money(p.price,c.currency);
 write(ctx,price,tx,horizontal?y+h-78:y+h-52,contentW,{weight:850,size:horizontal?36:29,color:t.accent,lines:1});
 if(!horizontal&&p.sku)write(ctx,p.sku,tx,y+h-84,contentW,{weight:600,size:14,color:'#8290A4'});
}
function renderPage(ctx,c,t,entries,pageNum,totalPages,logo){
 const first=pageNum===1;ctx.clearRect(0,0,WIDTH,HEIGHT);ctx.fillStyle='#F7F8FB';ctx.fillRect(0,0,WIDTH,HEIGHT);
 header(ctx,c,t,first,logo);
 const layout=c.layout==='revista'?'revista':'cuadricula',start=first?397:301;
 write(ctx,first?'LA COLECCIÓN':'MÁS PRODUCTOS',72,start-38,520,{weight:800,size:17,color:'#75839B'});
 write(ctx,`${c.products.length} PRODUCTOS  ·  ${c.currency}`,840,start-38,330,{weight:800,size:16,color:t.accent});
 if(layout==='revista')entries.forEach(({p,img},i)=>card(ctx,p,img,72,start+i*307,1096,288,t,c,'revista'));
 else entries.forEach(({p,img},i)=>card(ctx,p,img,72+(i%2)*560,start+Math.floor(i/2)*407,536,385,t,c,'cuadricula'));
 ctx.strokeStyle='#E2E7F1';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(72,1655);ctx.lineTo(1168,1655);ctx.stroke();
 write(ctx,c.contact||c.brand||'HMC CatalogPro',72,1680,850,{weight:600,size:19,color:'#64748B'});
 write(ctx,`${pageNum} / ${totalPages}`,1072,1680,96,{weight:800,size:19,color:t.accent});
}
function asJpegBytes(canvas){const data=canvas.toDataURL('image/jpeg',.87).split(',')[1],bin=atob(data),arr=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)arr[i]=bin.charCodeAt(i);return arr}
function buildPdf(jpegs){
 const encoder=new TextEncoder();const chunks=[];let offset=0;const offsets=[0];
 function add(value){const arr=typeof value==='string'?encoder.encode(value):value;chunks.push(arr);offset+=arr.length}
 function obj(n,head,stream){offsets[n]=offset;add(`${n} 0 obj\n${head}`);if(stream){add(`\nstream\n`);add(stream);add(`\nendstream`)}add(`\nendobj\n`)}
 add('%PDF-1.4\n%HMC\n');const count=jpegs.length;
 obj(1,'<< /Type /Catalog /Pages 2 0 R >>');
 const refs=jpegs.map((_,i)=>`${3+i*3} 0 R`).join(' ');obj(2,`<< /Type /Pages /Kids [${refs}] /Count ${count} >>`);
 jpegs.forEach((jpg,i)=>{const p=3+i*3,im=p+1,co=p+2;
  obj(p,`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /Im${i} ${im} 0 R >> >> /Contents ${co} 0 R >>`);
  obj(im,`<< /Type /XObject /Subtype /Image /Width ${WIDTH} /Height ${HEIGHT} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.length} >>`,jpg);
  const ops=`q\n595.28 0 0 841.89 0 0 cm\n/Im${i} Do\nQ\n`;obj(co,`<< /Length ${encoder.encode(ops).length} >>`,encoder.encode(ops));
 });
 const xrefOffset=offset,objects=2+3*count;
 add(`xref\n0 ${objects+1}\n0000000000 65535 f \n`);
 for(let n=1;n<=objects;n++)add(`${String(offsets[n]).padStart(10,'0')} 00000 n \n`);
 add(`trailer\n<< /Size ${objects+1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`);
 const combined=new Uint8Array(offset);let p=0;for(const chunk of chunks){combined.set(chunk,p);p+=chunk.length}return combined;
}
export async function downloadCatalogPdf(c,onProgress=()=>{}){
 if(!c.products.length)throw new Error('Primero añade al menos un producto al catálogo.');
 if(c.products.length>500)throw new Error('Por rendimiento, exporta como máximo 500 productos por PDF. Divide el catálogo en partes.');
 const pageSize=c.layout==='revista'?4:6;
 const total=Math.ceil(c.products.length/pageSize),t=themes[c.theme]||themes.violet;
 const canvas=document.createElement('canvas');canvas.width=WIDTH;canvas.height=HEIGHT;
 const ctx=canvas.getContext('2d',{alpha:false});if(!ctx)throw new Error('No se pudo crear el PDF en este navegador.');
 const logo=await loadImg(c.logo),jpegs=[];
 for(let page=0;page<total;page++){
  const products=c.products.slice(page*pageSize,(page+1)*pageSize);
  const entries=await Promise.all(products.map(async p=>({p,img:await loadImg(p.image)})));
  renderPage(ctx,c,t,entries,page+1,total,logo);jpegs.push(asJpegBytes(canvas));onProgress(page+1,total);
  await new Promise(resolve=>setTimeout(resolve,0));
 }
 const result=buildPdf(jpegs);
 downloadFile(`${fileStem(c.title)}.pdf`,result,'application/pdf');return {pages:total,bytes:result.length};
}
